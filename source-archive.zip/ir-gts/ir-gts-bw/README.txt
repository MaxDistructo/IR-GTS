IR-GTS README has been moved to https://code.google.com/p/ir-gts/wiki/Readme
