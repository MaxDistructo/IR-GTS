version = 'IR-GTS-BW, v0.05'
token = 'c9KcX1Cry3QKS2Ai7yxL6QiQGeBGeQKR'
salt = 'HZEdGCzcGGLvguqUEKQN'
